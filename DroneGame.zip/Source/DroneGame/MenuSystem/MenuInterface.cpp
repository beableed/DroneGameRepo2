// Fill out your copyright notice in the Description page of Project Settings.

#include "MenuInterface.h"


// Add default functionality here for any IMenuInterface functions that are not pure virtual.
